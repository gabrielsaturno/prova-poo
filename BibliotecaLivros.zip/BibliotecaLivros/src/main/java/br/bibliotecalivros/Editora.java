package br.bibliotecalivros;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Editora {
    private Integer codigoEditora;
    private String nomeEditora, cnpj;
    private List<Livro> livros = new LinkedList<>();

    public Editora() {
    }

    public Editora(Integer codigoEditora, String nomeEditora, String cnpj, List<Livro> livros) {
        this.codigoEditora = codigoEditora;
        this.nomeEditora = nomeEditora;
        this.cnpj = cnpj;
        this.livros = livros;
    }

    public Integer getCodigoEditora() {
        return codigoEditora;
    }

    public void setCodigoEditora(Integer codigoEditora) {
        this.codigoEditora = codigoEditora;
    }

    public String getNomeEditora() {
        return nomeEditora;
    }

    public void setNomeEditora(String nomeEditora) {
        this.nomeEditora = nomeEditora;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Editora editora = (Editora) o;
        return Objects.equals(codigoEditora, editora.codigoEditora) && Objects.equals(nomeEditora, editora.nomeEditora) && Objects.equals(cnpj, editora.cnpj) && Objects.equals(livros, editora.livros);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigoEditora, nomeEditora, cnpj, livros);
    }

    @Override
    public String toString() {
        return "Editora{" +
                "codigoEditora=" + codigoEditora +
                ", nomeEditora='" + nomeEditora + '\'' +
                ", cnpj='" + cnpj + '\'' +
                ", livros=" + livros +
                '}';
    }
}