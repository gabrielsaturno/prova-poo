package br.bibliotecalivros;

import java.util.Objects;

public class Livro {
    Integer codigoLivro, anoPublicacao;
    String titulo, autor;
    Double preco;

    public static void main(String[] args) {
     var livro001 = new Livro();
     var livro002 = new Livro();

     livro001.codigoLivro = 001;
     livro001.titulo = "Doctor Who - Shada";
     livro001.anoPublicacao = 2013;
     livro001.autor = "Douglas Adamns";
     livro001.preco = 39.90;

     livro002.codigoLivro = 002;
     livro002.titulo = "A Cabana";
     livro002.anoPublicacao = 2005;
     livro002.autor = "ABC";
     livro002.preco = 19.90;

     System.out.println(livro001);
     System.out.println(livro002);

    }
    public Livro() {
    }

    public Livro(Integer codigoLivro, Integer anoPublicacao, String titulo, String autor, Double preco) {
        this.codigoLivro = codigoLivro;
        this.anoPublicacao = anoPublicacao;
        this.titulo = titulo;
        this.autor = autor;
        this.preco = preco;
    }

    public Integer getCodigoLivro() {
        return codigoLivro;
    }

    public void setCodigoLivro(Integer codigoLivro) {
        this.codigoLivro = codigoLivro;
    }

    public Integer getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(Integer anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Livro livro = (Livro) o;
        return Objects.equals(codigoLivro, livro.codigoLivro) && Objects.equals(anoPublicacao, livro.anoPublicacao) && Objects.equals(titulo, livro.titulo) && Objects.equals(autor, livro.autor) && Objects.equals(preco, livro.preco);
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigoLivro, anoPublicacao, titulo, autor, preco);
    }

    @Override
    public String toString() {
        return "Livro{" +
                "codigoLivro=" + codigoLivro +
                ", anoPublicacao=" + anoPublicacao +
                ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", preco=" + preco +
                '}';
    }
}
